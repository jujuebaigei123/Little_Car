# BIT-Shanghai-AGV
This package is only applicable to the BIT-AGV-Shanghai project

## Tnstall ##
Using Ubuntu 20.04 system and ROS noetic, place all files under the **src** folder and compile using *catkin_make*

## Usage ##
coming soon……

