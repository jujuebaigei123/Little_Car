#! /usr/bin/env python3
# -*- coding: utf-8 -*-
# Date: 2024/7/17

import paho.mqtt.client as mqtt
import rospy, tf
import json
from tf.transformations import euler_from_quaternion
from gps.msg import MyGPS_msg
from std_msgs.msg import Float64
import math
actor = None
actor=rospy.get_param('/simple_pub/actor',None)
print(actor)
msg_dict={"vel": 0, 
          "remainpath": None,
          "passedpath": 0,
          "actor":actor,
          "pose":{
                    "x":None,
                    "y":None,
                    "heading":None,
                    "vel":None
        }
    }

last_pose = None
flag = False

def gps_callback(msg:MyGPS_msg):
    msg_dict["vel"]=msg.Vel

def remainpath_callback(msg:Float64):
    msg_dict["remainpath"]=msg.data   

def passedpath_callback(msg:Float64):
    msg_dict["passedpath"]=msg.data 
    
rospy.init_node('mqtt_to_ros_publisher')
rospy.Subscriber('/gps_base/GPS_Base', MyGPS_msg, gps_callback)
rospy.Subscriber('/local_path_plan/remainpath', Float64, remainpath_callback)
rospy.Subscriber('/local_path_plan/passedpath', Float64, passedpath_callback)
dogId=rospy.get_param('/dogId',"dog000")

# MQTT连接参数
mqtt_broker = rospy.get_param('/broker',"192.168.2.115")
mqtt_port = 1883
mqtt_topic = "wsk/test/"+dogId

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print(dogId+" Connected to MQTT Broker!\n")
    else:
        print(dogId+" Failed to connect, return code %d\n", rc)

client = mqtt.Client()
client.on_connect = on_connect
client.connect(mqtt_broker, mqtt_port, 60)
client.loop_start()

def get_transform():
    # 创建一个 tf 监听器
    listener = tf.TransformListener()
    point={}
    # 等待接收坐标变换信息
    try:
        # 等待获取 base_link 到 map 的坐标变换信息，最多等待 1 秒
        listener.waitForTransform('map', 'base_link', rospy.Time(0), rospy.Duration(1.0))
    except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
        rospy.logerr("Failed to wait for transform!")
        # return

    try:
        # 查询 base_link 到 map 的坐标变换
        (trans, rot) = listener.lookupTransform('map', 'base_link', rospy.Time(0))
        roll, pitch, yaw = euler_from_quaternion(rot)
        point["x"]=trans[0]
        point["y"]=trans[1]
        point["angle"]=yaw
        # rospy.loginfo("Translation: %s", trans)
        # rospy.loginfo("Rotation: %s", rot)
    except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
        rospy.logerr("Failed to get transform!")

    return point  

def get_current_pose():
    """获取当前位姿 (x, y, heading)"""
    listener = tf.TransformListener()
    try:
        # 等待获取 base_link 到 map 的坐标变换信息
        listener.waitForTransform('map', 'base_link', rospy.Time(0), rospy.Duration(0.1))
        (trans, rot) = listener.lookupTransform('map', 'base_link', rospy.Time(0))
        roll, pitch, yaw = euler_from_quaternion(rot)
        return {
            "x": trans[0],
            "y": trans[1],
            "heading": yaw*180/math.pi
        }

    except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException, tf.Exception) as e:
        rospy.logwarn("Failed to get transform: %s", str(e))
        return None  

his_path=[]

def add_path_point():
    global his_path
    point=get_transform()
    dis=100
    if(len(his_path)>0):
        dis=((point["x"]-his_path[-1]["x"])**2+(point["y"]-his_path[-1]["y"])**2)**0.5

    if(dis>0.5):  
        if len(his_path)>=10:
            his_path.pop(0)
        his_path.append(point)

    # print(point)   
    
def timer_callback(event):
    msg_dict["id"]=dogId

    # state = rospy.get_param("/dog_state",0)
    # msg_dict["state"] = state
    # add_path_point()
    # msg_dict["his_path"]=his_path

    
    # msg_dict["id"]=dogId
    # # add_path_point()
    # # msg_dict["his_path"]=his_path

    # msg_json=json.dumps(msg_dict)
    # client.publish(mqtt_topic, msg_json)  

    global last_pose,flag
    
    # 获取当前位姿
    current_pose  = get_current_pose()
    if current_pose is None:
        return
    if(not flag):
        msg_dict["pose"]["x"]=current_pose["x"]
        msg_dict["pose"]["y"]=current_pose["y"]
        msg_dict["pose"]["heading"]=current_pose["heading"]
        msg_dict["pose"]["vel"]=msg_dict["vel"]
        flag=True
        last_pose=current_pose
                
    # 如果是第一次获取位置，直接发送并记录
    # if last_pose is None:
    #     send_pose_data()
    #     last_pose = current_pose
    #     return
    
    
    # 计算移动距离
    dx = current_pose["x"] - last_pose["x"]
    dy = current_pose["y"] - last_pose["y"]
    distance = math.sqrt(dx**2 + dy**2)

    
    # 每移动0.5米发送一次
    if distance >= 1.0:
        msg_dict["pose"]["x"]=current_pose["x"]
        msg_dict["pose"]["y"]=current_pose["y"]
        msg_dict["pose"]["heading"]=current_pose["heading"]
        msg_dict["pose"]["vel"]=msg_dict["vel"]
        last_pose = current_pose 
    msg_json=json.dumps(msg_dict)
    client.publish(mqtt_topic, msg_json)  


# 设置定时器，每隔一定时间触发回调函数
rate = rospy.Rate(0.2)  # 每秒钟触发一次定时器回调函数
rospy.Timer(rospy.Duration(1.0 / rate.sleep_dur.to_sec()), timer_callback)
rospy.spin()

client.loop_stop()
client.disconnect()
