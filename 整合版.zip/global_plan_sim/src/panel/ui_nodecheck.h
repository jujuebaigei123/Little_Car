/********************************************************************************
** Form generated from reading UI file 'node_check.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NODECHECK_H
#define UI_NODECHECK_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Dialog_NodeCheck
{
public:
    QGroupBox *groupBox_2;
    QLabel *label_25;
    QLabel *label_lidar_hb;
    QLabel *label_27;
    QLabel *label_if_hb;
    QLabel *label_carctr_hb;
    QLabel *label_29;
    QLabel *label_30;
    QLabel *label_ccd_hb;
    QLabel *label_31;
    QLabel *label_slam_hb;
    QLabel *label_32;
    QLabel *label_station_hb;
    QLabel *label_battery_hb;
    QLabel *label_33;
    QLabel *label_34;
    QLabel *label_turntable_hb;

    void setupUi(QDialog *Dialog_NodeCheck)
    {
        if (Dialog_NodeCheck->objectName().isEmpty())
            Dialog_NodeCheck->setObjectName(QString::fromUtf8("Dialog_NodeCheck"));
        Dialog_NodeCheck->resize(723, 295);
        groupBox_2 = new QGroupBox(Dialog_NodeCheck);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(20, 20, 681, 251));
        QFont font;
        font.setPointSize(14);
        groupBox_2->setFont(font);
        groupBox_2->setStyleSheet(QString::fromUtf8("background-color: rgb(114, 159, 207);\n"
"gridline-color: rgb(0, 0, 0);"));
        label_25 = new QLabel(groupBox_2);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(230, 40, 91, 31));
        label_25->setFont(font);
        label_lidar_hb = new QLabel(groupBox_2);
        label_lidar_hb->setObjectName(QString::fromUtf8("label_lidar_hb"));
        label_lidar_hb->setGeometry(QRect(340, 40, 51, 31));
        label_lidar_hb->setFont(font);
        label_lidar_hb->setStyleSheet(QString::fromUtf8("color: rgb(238, 238, 236);\n"
"background-color: rgb(143, 89, 2);"));
        label_lidar_hb->setFrameShape(QFrame::Box);
        label_lidar_hb->setFrameShadow(QFrame::Raised);
        label_lidar_hb->setAlignment(Qt::AlignCenter);
        label_27 = new QLabel(groupBox_2);
        label_27->setObjectName(QString::fromUtf8("label_27"));
        label_27->setGeometry(QRect(440, 40, 101, 30));
        label_27->setFont(font);
        label_if_hb = new QLabel(groupBox_2);
        label_if_hb->setObjectName(QString::fromUtf8("label_if_hb"));
        label_if_hb->setGeometry(QRect(550, 40, 51, 30));
        label_if_hb->setFont(font);
        label_if_hb->setStyleSheet(QString::fromUtf8("color: rgb(238, 238, 236);\n"
"background-color: rgb(143, 89, 2);"));
        label_if_hb->setFrameShape(QFrame::Box);
        label_if_hb->setFrameShadow(QFrame::Raised);
        label_if_hb->setAlignment(Qt::AlignCenter);
        label_carctr_hb = new QLabel(groupBox_2);
        label_carctr_hb->setObjectName(QString::fromUtf8("label_carctr_hb"));
        label_carctr_hb->setGeometry(QRect(340, 100, 51, 31));
        label_carctr_hb->setFont(font);
        label_carctr_hb->setStyleSheet(QString::fromUtf8("color: rgb(238, 238, 236);\n"
"background-color: rgb(143, 89, 2);"));
        label_carctr_hb->setFrameShape(QFrame::Box);
        label_carctr_hb->setFrameShadow(QFrame::Raised);
        label_carctr_hb->setAlignment(Qt::AlignCenter);
        label_29 = new QLabel(groupBox_2);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setGeometry(QRect(230, 100, 101, 31));
        label_29->setFont(font);
        label_30 = new QLabel(groupBox_2);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setGeometry(QRect(20, 100, 101, 31));
        label_30->setFont(font);
        label_ccd_hb = new QLabel(groupBox_2);
        label_ccd_hb->setObjectName(QString::fromUtf8("label_ccd_hb"));
        label_ccd_hb->setGeometry(QRect(130, 100, 51, 31));
        label_ccd_hb->setFont(font);
        label_ccd_hb->setStyleSheet(QString::fromUtf8("color: rgb(238, 238, 236);\n"
"background-color: rgb(143, 89, 2);"));
        label_ccd_hb->setFrameShape(QFrame::Box);
        label_ccd_hb->setFrameShadow(QFrame::Raised);
        label_ccd_hb->setAlignment(Qt::AlignCenter);
        label_31 = new QLabel(groupBox_2);
        label_31->setObjectName(QString::fromUtf8("label_31"));
        label_31->setGeometry(QRect(20, 42, 81, 31));
        label_31->setFont(font);
        label_slam_hb = new QLabel(groupBox_2);
        label_slam_hb->setObjectName(QString::fromUtf8("label_slam_hb"));
        label_slam_hb->setGeometry(QRect(130, 42, 51, 31));
        label_slam_hb->setFont(font);
        label_slam_hb->setStyleSheet(QString::fromUtf8("color: rgb(238, 238, 236);\n"
"background-color: rgb(143, 89, 2);"));
        label_slam_hb->setFrameShape(QFrame::Box);
        label_slam_hb->setFrameShadow(QFrame::Raised);
        label_slam_hb->setAlignment(Qt::AlignCenter);
        label_32 = new QLabel(groupBox_2);
        label_32->setObjectName(QString::fromUtf8("label_32"));
        label_32->setGeometry(QRect(440, 100, 101, 31));
        label_32->setFont(font);
        label_station_hb = new QLabel(groupBox_2);
        label_station_hb->setObjectName(QString::fromUtf8("label_station_hb"));
        label_station_hb->setGeometry(QRect(550, 100, 51, 31));
        label_station_hb->setFont(font);
        label_station_hb->setStyleSheet(QString::fromUtf8("color: rgb(238, 238, 236);\n"
"background-color: rgb(143, 89, 2);"));
        label_station_hb->setFrameShape(QFrame::Box);
        label_station_hb->setFrameShadow(QFrame::Raised);
        label_station_hb->setAlignment(Qt::AlignCenter);
        label_battery_hb = new QLabel(groupBox_2);
        label_battery_hb->setObjectName(QString::fromUtf8("label_battery_hb"));
        label_battery_hb->setGeometry(QRect(130, 160, 51, 31));
        label_battery_hb->setFont(font);
        label_battery_hb->setStyleSheet(QString::fromUtf8("color: rgb(238, 238, 236);\n"
"background-color: rgb(143, 89, 2);"));
        label_battery_hb->setFrameShape(QFrame::Box);
        label_battery_hb->setFrameShadow(QFrame::Raised);
        label_battery_hb->setAlignment(Qt::AlignCenter);
        label_33 = new QLabel(groupBox_2);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        label_33->setGeometry(QRect(20, 160, 101, 31));
        label_33->setFont(font);
        label_34 = new QLabel(groupBox_2);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        label_34->setGeometry(QRect(230, 160, 101, 31));
        label_34->setFont(font);
        label_turntable_hb = new QLabel(groupBox_2);
        label_turntable_hb->setObjectName(QString::fromUtf8("label_turntable_hb"));
        label_turntable_hb->setGeometry(QRect(340, 160, 51, 31));
        label_turntable_hb->setFont(font);
        label_turntable_hb->setStyleSheet(QString::fromUtf8("color: rgb(238, 238, 236);\n"
"background-color: rgb(143, 89, 2);"));
        label_turntable_hb->setFrameShape(QFrame::Box);
        label_turntable_hb->setFrameShadow(QFrame::Raised);
        label_turntable_hb->setAlignment(Qt::AlignCenter);

        retranslateUi(Dialog_NodeCheck);

        QMetaObject::connectSlotsByName(Dialog_NodeCheck);
    } // setupUi

    void retranslateUi(QDialog *Dialog_NodeCheck)
    {
        Dialog_NodeCheck->setWindowTitle(QApplication::translate("Dialog_NodeCheck", "\345\205\250\347\263\273\347\273\237\347\212\266\346\200\201\346\243\200\346\265\213", nullptr));
        groupBox_2->setTitle(QString());
        label_25->setText(QApplication::translate("Dialog_NodeCheck", "\346\277\200\345\205\211\351\233\267\350\276\276", nullptr));
        label_lidar_hb->setText(QApplication::translate("Dialog_NodeCheck", "0", nullptr));
        label_27->setText(QApplication::translate("Dialog_NodeCheck", "\347\272\242\345\244\226\347\233\270\346\234\272", nullptr));
        label_if_hb->setText(QApplication::translate("Dialog_NodeCheck", "0", nullptr));
        label_carctr_hb->setText(QApplication::translate("Dialog_NodeCheck", "0", nullptr));
        label_29->setText(QApplication::translate("Dialog_NodeCheck", "\345\260\217\350\275\246\345\272\225\347\233\230", nullptr));
        label_30->setText(QApplication::translate("Dialog_NodeCheck", "CCD", nullptr));
        label_ccd_hb->setText(QApplication::translate("Dialog_NodeCheck", "0", nullptr));
        label_31->setText(QApplication::translate("Dialog_NodeCheck", "Slam\345\256\232\344\275\215", nullptr));
        label_slam_hb->setText(QApplication::translate("Dialog_NodeCheck", "0", nullptr));
        label_32->setText(QApplication::translate("Dialog_NodeCheck", "\345\205\205\347\224\265\347\253\231", nullptr));
        label_station_hb->setText(QApplication::translate("Dialog_NodeCheck", "0", nullptr));
        label_battery_hb->setText(QApplication::translate("Dialog_NodeCheck", "0", nullptr));
        label_33->setText(QApplication::translate("Dialog_NodeCheck", "\347\224\265\346\261\240BMS", nullptr));
        label_34->setText(QApplication::translate("Dialog_NodeCheck", "\344\274\272\346\234\215\350\275\254\345\217\260", nullptr));
        label_turntable_hb->setText(QApplication::translate("Dialog_NodeCheck", "0", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog_NodeCheck: public Ui_Dialog_NodeCheck {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NODECHECK_H
