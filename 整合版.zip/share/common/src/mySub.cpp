#include "common/mySub.h"

using namespace std;


// template <class T1, class T2>
// float TSub<T1, T2>::GetHZ()
// {
//     // return hb.value;
//     return 0;
// }


// TUInt16_Sub::TUInt16_Sub(ros::NodeHandle &nh, string topic_name, size_t buff_size):TSub(nh, topic_name, buff_size)
// {
// }


// TSub::TString_Sub(ros::NodeHandle &nh, string topic_name, size_t buff_size = 10) : TSub(nh, topic_name, buff_size)
// {
// }


// TSub::TPointCloud_Sub(ros::NodeHandle &nh, string topic_name, size_t buff_size = 10) : TSub(nh, topic_name, buff_size)
// {
// }


// TPointStamped_Sub::TPointStamped_Sub(ros::NodeHandle &nh, string topic_name, size_t buff_size) : TSub(nh, topic_name, buff_size)
// {
// }

